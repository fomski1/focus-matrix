
import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { ProductOverview } from './components/ProductOverview';
import { GumroadListing } from './components/GumroadListing';
import { PromptPack } from './components/PromptPack';
import { QuickStartGuide } from './components/QuickStartGuide';
import { BonusContent } from './components/BonusContent';
import { MarketingAssets } from './components/MarketingAssets';
import { LaunchPlan } from './components/LaunchPlan';

type View = 'overview' | 'gumroad' | 'prompts' | 'guide' | 'bonus' | 'marketing' | 'launch';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('overview');

  const renderView = () => {
    switch (currentView) {
      case 'overview': return <ProductOverview />;
      case 'gumroad': return <GumroadListing />;
      case 'prompts': return <PromptPack />;
      case 'guide': return <QuickStartGuide />;
      case 'bonus': return <BonusContent />;
      case 'marketing': return <MarketingAssets />;
      case 'launch': return <LaunchPlan />;
      default: return <ProductOverview />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      <main className="flex-1 p-4 md:p-10 max-w-5xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">
            🎯 COMPLETE AI PROMPT PACK - READY TO SELL
          </h1>
          <p className="text-slate-500 mt-2">
            The ADHD Entrepreneur's Focus Matrix: 30+ AI Prompts for Distraction-Free Business Growth.
          </p>
        </header>
        {renderView()}
      </main>
    </div>
  );
};

export default App;
