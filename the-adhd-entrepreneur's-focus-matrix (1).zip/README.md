# 🌴 The ADHD Entrepreneur's Focus Matrix - Hosting Guide

This dashboard is designed to be a "No-Build" React application. This means it can be hosted on any static web server without needing to run `npm build`.

## 🚀 Fast Hosting (Netlify Drop)
1. Create a folder on your computer.
2. Download all files from this project into that folder.
3. Go to [Netlify Drop](https://app.netlify.com/drop).
4. Drag and drop the folder.
5. Your site is live!

## 🛠 Professional Hosting (Vercel)
1. Create a [Vercel](https://vercel.com) account.
2. Connect your GitHub repository or upload the folder directly to the Vercel dashboard.
3. Use default settings (no build command required).

## 📄 Creating the Product PDF
1. Open your live hosted URL.
2. Navigate to the **The Prompt Pack** section.
3. Use your browser's print function (`Ctrl+P` or `Cmd+P`).
4. Select **Save as PDF**.
5. Upload this PDF to Gumroad as your digital product.

## 💰 Gumroad Checklist (St. Lucia)
- **Currency**: Set to USD.
- **Payouts**: Link your PayPal or Stripe account.
- **Redirect**: You can set Gumroad to redirect buyers to your live dashboard URL after purchase for a "Premium" experience.
