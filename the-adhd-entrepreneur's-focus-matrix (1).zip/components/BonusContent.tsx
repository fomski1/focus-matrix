
import React from 'react';
import { FAQ_DATA } from '../constants';

export const BonusContent: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="bg-indigo-900 text-white p-8 rounded-2xl shadow-lg">
        <h2 className="text-2xl font-bold mb-4">🎁 Bonus Content</h2>
        <div className="space-y-6">
          <div className="p-4 bg-indigo-800/50 rounded-xl border border-indigo-700">
            <h3 className="font-bold text-indigo-300 uppercase text-xs mb-2">Secret Advanced Prompt</h3>
            <p className="text-sm font-semibold mb-2">The "Neural Clone" Logic Prompt</p>
            <p className="text-xs text-indigo-200">"Analyze these 5 writing samples of mine. Extract my linguistic patterns, my common metaphors, and my sentence structure. From now on, whenever I ask you to write, apply this 'Voice Profile' to every output without me asking."</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div className="p-4 bg-indigo-800/50 rounded-xl border border-indigo-700">
              <h3 className="font-bold text-indigo-300 uppercase text-xs mb-1">Notion Template Structure</h3>
              <p className="text-xs text-indigo-200">A visual guide on how to set up your 'Focus Matrix' Dashboard with linked databases for Tasks, Content, and AI Outputs.</p>
            </div>
             <div className="p-4 bg-indigo-800/50 rounded-xl border border-indigo-700">
              <h3 className="font-bold text-indigo-300 uppercase text-xs mb-1">Weekly Workflow Template</h3>
              <p className="text-xs text-indigo-200">A repeatable checklist for Friday Close-downs and Monday Kick-offs to ensure no tasks fall through the cracks.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold mb-6">Troubleshooting FAQ</h2>
        <div className="space-y-6">
          {FAQ_DATA.map((faq, i) => (
            <div key={i}>
              <h3 className="font-bold text-slate-800 text-sm mb-1">Q: {faq.question}</h3>
              <p className="text-slate-600 text-sm">A: {faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
