
import React from 'react';

export const GumroadListing: React.FC = () => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  const description = `Stop Fighting Your Brain. Start Building Your Empire.

Do you have 50 tabs open, a heart full of ambition, but a brain that feels like it's stuck in "waiting mode"?

For the solo entrepreneur with ADHD, the hardest part of business isn't the big ideas—it's the "boring" stuff. The emails, the task lists, the content schedules, and the decision-making that leads to burnout before noon.

"The ADHD Entrepreneur’s Focus Matrix" is your external frontal lobe. It’s a specialized pack of 30+ high-performance AI prompts specifically engineered for neurodivergent entrepreneurs. These aren't just "writing prompts"—they are systems designed to bridge the executive function gap.

What’s Inside?
• ⚡ The Executive Function Bridge: Prompts to turn brain-dumps into organized plans.
• ✍️ The Content Hyperfocus: Create a month of content without the creative block.
• 📧 The Communication Buffer: Professionalize your inbox without the emotional labor.
• 🛑 The Procrastination Reset: Prompts to break task paralysis in seconds.
• 🧠 The CEO Strategy Session: AI-assisted high-level planning.

Stop apologizing for how your brain works. Use it.`;

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold mb-4">Gumroad SEO & Title</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">PRODUCT TITLE (Max 10 Words)</label>
            <div className="flex items-center gap-2">
              <input readOnly value="The ADHD Entrepreneur's Focus Matrix: 30+ AI Prompts" className="flex-1 p-2 bg-slate-50 rounded border border-slate-200 font-medium" />
              <button onClick={() => copyToClipboard("The ADHD Entrepreneur's Focus Matrix: 30+ AI Prompts")} className="bg-indigo-600 text-white px-4 py-2 rounded text-sm">Copy</button>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1">SEO KEYWORDS</label>
            <p className="text-sm text-slate-600 italic">ADHD Productivity, AI Prompts, Solo Entrepreneur, Focus Hacks, Executive Function, Business Growth, ChatGPT for ADHD, Neural Workflow, Task Management, Time Blocking</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold mb-4">Conversion-Optimized Description</h2>
        <textarea readOnly value={description} rows={12} className="w-full p-4 bg-slate-50 rounded-xl border border-slate-200 text-sm mb-4" />
        <button onClick={() => copyToClipboard(description)} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold">Copy Listing Description</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-2xl">
          <h3 className="font-bold text-emerald-800 mb-2">Pricing Strategy</h3>
          <p className="text-sm text-emerald-700">Regular Price: <span className="font-bold">$47</span></p>
          <p className="text-sm text-emerald-700 font-bold">Launch Discount: $27 (Next 48 Hours)</p>
          <p className="text-xs text-emerald-600 mt-2 italic">Use a limited-time coupon "FOCUSFIRST" for the best conversion rate.</p>
        </div>
        <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl">
          <h3 className="font-bold text-indigo-800 mb-2">Customer Benefits</h3>
          <ul className="text-xs text-indigo-700 space-y-1">
            <li>• Save 10+ hours a week on "admin drag"</li>
            <li>• End the day with a "Checked" list, not just "Pending"</li>
            <li>• Scale your business without hiring a VA</li>
            <li>• Turn creative chaos into consistent cashflow</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
