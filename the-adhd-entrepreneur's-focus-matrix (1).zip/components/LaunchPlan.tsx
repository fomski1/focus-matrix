
import React from 'react';

export const LaunchPlan: React.FC = () => {
  const days = [
    { day: "Day 1", action: "Finalize Assets", tasks: ["Export this guide as a PDF", "Create 3 Gumroad thumbnail images in Canva (1280x720)", "Set up the Gumroad product page"] },
    { day: "Day 2", action: "Pre-Launch Tease", tasks: ["Post a screenshot of one 'Success Output' on Twitter/Instagram", "Ask: 'Who else struggles with task paralysis?'", "Don't sell yet, just start the conversation"] },
    { day: "Day 3", action: "Value Drop", tasks: ["Give away ONE prompt for free in a LinkedIn post", "Show exactly how it works with a screen recording", "Mention the pack is coming in 48 hours"] },
    { day: "Day 4", action: "The Waitlist / Final Check", tasks: ["Review your Gumroad checkout flow", "Send a direct message to anyone who interacted with your previous posts", "Tell them to 'Watch this space tomorrow morning'"] },
    { day: "Day 5", action: "LAUNCH DAY", tasks: ["Post the Twitter thread provided in 'Marketing Assets'", "Change bio link to Gumroad", "Send the announcement email", "Reply to every single comment to boost the algorithm"] }
  ];

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold mb-6">5-Day Launch Checklist</h2>
        <div className="space-y-6">
          {days.map((item, i) => (
            <div key={i} className="relative pl-8 pb-8 border-l-2 border-slate-100 last:border-0 last:pb-0">
              <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-indigo-600" />
              <h3 className="font-bold text-slate-800 text-lg mb-1">{item.day}: {item.action}</h3>
              <ul className="space-y-1">
                {item.tasks.map((task, j) => (
                  <li key={j} className="text-sm text-slate-600 flex items-center gap-2">
                    <input type="checkbox" className="rounded text-indigo-600" /> {task}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-indigo-50 p-8 rounded-2xl border border-indigo-100">
        <h3 className="font-bold text-indigo-900 mb-2">Final Success Advice</h3>
        <p className="text-sm text-indigo-800 leading-relaxed">
          Selling from St. Lucia is easy on Gumroad, but consistency is the key. Once launched, try to share one "AI Focus Hack" every week to keep traffic flowing to your link. Your first $1,000 month is closer than you think.
        </p>
      </div>
    </div>
  );
};
