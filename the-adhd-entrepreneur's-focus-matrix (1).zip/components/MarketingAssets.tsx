
import React from 'react';
import { MARKETING_DATA } from '../constants';

export const MarketingAssets: React.FC = () => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied!');
  };

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold mb-6 text-slate-900 underline decoration-indigo-500 underline-offset-8">Social Media & Email Templates</h2>
        
        {MARKETING_DATA.map((asset, i) => (
          <div key={i} className="mb-10 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-indigo-600 uppercase text-sm">{asset.platform}</h3>
              <button onClick={() => copyToClipboard(asset.content)} className="text-xs bg-slate-100 px-3 py-1 rounded-md hover:bg-slate-200">Copy Content</button>
            </div>
            <div className="p-6 bg-slate-50 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap font-mono border border-slate-100">
              {asset.content}
            </div>
          </div>
        ))}

        <div className="space-y-4">
          <h3 className="font-bold text-indigo-600 uppercase text-sm">Instagram Caption (150 Words)</h3>
          <div className="p-6 bg-slate-50 rounded-2xl text-sm leading-relaxed border border-slate-100">
            <p>Ever feel like you have 50 tabs open in your brain, but only 1 works? 🧠⚡️<br/><br/>
            As an ADHD entrepreneur, the struggle is real. The big ideas? Easy. The daily admin? Paralyzing. <br/><br/>
            That’s why I built The ADHD Entrepreneur's Focus Matrix. It’s 30+ AI prompts engineered to act as your external frontal lobe. From breaking the "Wall of Awful" to planning a month of content in minutes, this is the system your brain has been waiting for.<br/><br/>
            Stop fighting your biology. Start automating your focus.<br/><br/>
            🔗 Link in bio to grab it for $27 (Launch Price!) #ADHD #Entrepreneur #Productivity #AIPrompts #Neurodivergent</p>
          </div>
        </div>

        <div className="mt-10 space-y-4">
          <h3 className="font-bold text-indigo-600 uppercase text-sm">Email to First 100 Buyers</h3>
          <div className="p-6 bg-slate-50 rounded-2xl text-sm leading-relaxed border border-slate-100">
            <p>Subject: Welcome to the Focus Matrix (Let's get started!)<br/><br/>
            Hey [Name],<br/><br/>
            You did it. You decided to stop fighting your brain and start using a system built for you.<br/><br/>
            Attached is your Focus Matrix Prompt Pack. <br/><br/>
            My advice? Start with Category 1, Prompt #1 (The Chaotic Brain-Dump). It's the fastest way to feel an immediate sense of relief today.<br/><br/>
            If you have questions, just hit reply. I'm rooting for you!<br/><br/>
            Cheers,<br/>[Your Name]</p>
          </div>
        </div>
      </div>
    </div>
  );
};
