
import React from 'react';

export const ProductOverview: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold mb-4">1. Product Foundation</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-400 uppercase">Niche Selection</label>
              <p className="text-slate-700 font-medium">ADHD-Friendly Productivity for Solo Entrepreneurs</p>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 uppercase">Target Pain Point</label>
              <p className="text-slate-700">Solo business owners with ADHD struggling with executive dysfunction, "The Wall of Awful," and daily task paralysis.</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-400 uppercase">Price Point</label>
              <p className="text-slate-700 font-bold text-lg">$37.00 USD</p>
              <p className="text-xs text-slate-500 italic">Sweet spot for high-value neurodivergent assets.</p>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-400 uppercase">St. Lucia / Gumroad Eligibility</label>
              <p className="text-slate-700">Fully accessible. Payments can be processed via Stripe/PayPal integrations available to St. Lucian sellers.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-indigo-600 text-white p-8 rounded-2xl shadow-lg">
        <h2 className="text-2xl font-bold mb-4">2. Positioning & Value Prop</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-indigo-100 text-sm font-semibold uppercase mb-1">Product Name</h3>
            <p className="text-2xl font-bold">The ADHD Entrepreneur's Focus Matrix</p>
          </div>
          <div>
            <h3 className="text-indigo-100 text-sm font-semibold uppercase mb-1">Value Proposition</h3>
            <p className="text-xl">Stop fighting your brain and start using AI as your external frontal lobe to automate the executive function tasks that drain your energy.</p>
          </div>
          <div>
            <h3 className="text-indigo-100 text-sm font-semibold uppercase mb-2">What the buyer gets</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">✅ 30+ Tested AI Prompts for Neurodivergent Brains</li>
              <li className="flex items-center gap-2">✅ The Focus Matrix Dashboard (Notion Structure)</li>
              <li className="flex items-center gap-2">✅ Daily/Weekly Workflow Automations</li>
              <li className="flex items-center gap-2">✅ The "Emergency Reset" Procrastination Killers</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
