
import React from 'react';
import { PROMPT_PACK_DATA } from '../constants';

export const PromptPack: React.FC = () => {
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    alert(`${label} copied!`);
  };

  const copyCategory = (categoryIndex: number) => {
    const category = PROMPT_PACK_DATA[categoryIndex];
    const allPrompts = category.prompts.map(p => `--- ${p.title} ---\n\nPROMPT:\n${p.text}\n\nUSE CASE: ${p.useCase}\n\n`).join('\n');
    copyToClipboard(allPrompts, category.name);
  };

  return (
    <div className="space-y-12">
      {PROMPT_PACK_DATA.map((category, idx) => (
        <section key={idx} className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-l-4 border-indigo-600 pl-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">{category.name}</h2>
              <p className="text-slate-500">{category.description}</p>
            </div>
            <button 
              onClick={() => copyCategory(idx)}
              className="flex items-center gap-2 text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 px-4 py-2 rounded-xl hover:bg-indigo-100 transition-all"
            >
              <span>📂</span> Copy All {category.prompts.length} Prompts
            </button>
          </div>
          
          <div className="grid grid-cols-1 gap-8">
            {category.prompts.map((prompt) => (
              <div key={prompt.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden group hover:border-indigo-300 transition-colors">
                <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                  <h3 className="font-bold text-lg text-slate-800">{prompt.title}</h3>
                  <button 
                    onClick={() => copyToClipboard(prompt.text, 'Prompt')}
                    className="flex items-center gap-2 text-xs font-bold bg-white border border-slate-200 px-3 py-1.5 rounded-lg hover:bg-slate-100 group-hover:bg-indigo-600 group-hover:text-white group-hover:border-indigo-600 transition-all"
                  >
                    <span>📋</span> Copy
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest block mb-2">The Prompt</span>
                    <div className="p-4 bg-slate-900 text-slate-300 rounded-xl text-sm leading-relaxed font-mono whitespace-pre-wrap">
                      {prompt.text}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
                      <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest block mb-1">Example Input</span>
                      <p className="text-xs text-emerald-800 italic">"{prompt.inputExample}"</p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                      <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest block mb-1">Expected Output</span>
                      <p className="text-xs text-blue-800 italic">"{prompt.outputExample}"</p>
                    </div>
                  </div>
                  <div className="pt-2 text-xs text-slate-400">
                    <strong>When to use:</strong> {prompt.useCase}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ))}
      <div className="bg-slate-900 text-white p-10 rounded-3xl text-center shadow-2xl">
        <h3 className="text-xl font-bold mb-2">🎉 You've Reached the End of the Matrix</h3>
        <p className="text-slate-400 text-sm max-w-lg mx-auto">These 30 prompts are your new secret weapon. Use them consistently, and you'll see your business transform as your executive function gap closes.</p>
      </div>
    </div>
  );
};
