
import React from 'react';

export const QuickStartGuide: React.FC = () => {
  const steps = [
    { title: "Access & Organize", desc: "Download the Focus Matrix PDF and copy your favorite prompts into a Notion page or a 'Prompts' folder in your browser bookmarks for 1-click access." },
    { title: "The 'Bracket' Method", desc: "Every prompt has [Brackets]. When you paste the prompt into ChatGPT/Claude, make sure to replace the bracketed text with your specific details." },
    { title: "Choose Your Model", desc: "For planning and logic, use ChatGPT-4o. For writing and voice, use Claude 3.5 Sonnet. For quick summaries, Gemini 2.0 Flash works great." },
    { title: "Iterate, Don't Restart", desc: "If the AI doesn't get it right the first time, don't start a new chat. Say: 'That's close, but make it less formal' or 'You missed step 3, please try again.'" },
    { title: "Weekly Review", desc: "Every Sunday, use the 'CEO Strategy' prompt from Category 5 to review what worked and what didn't. This prevents the 'Sunday Scaries'." }
  ];

  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
      <h2 className="text-2xl font-bold mb-6">Quick-Start Implementation Guide</h2>
      <div className="space-y-8">
        {steps.map((step, i) => (
          <div key={i} className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold">
              {i + 1}
            </div>
            <div>
              <h3 className="font-bold text-slate-800">{step.title}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-10 p-6 bg-amber-50 rounded-xl border border-amber-100">
        <h3 className="font-bold text-amber-800 text-sm mb-2 uppercase">Common Mistakes to Avoid</h3>
        <ul className="text-xs text-amber-700 space-y-2">
          <li>❌ <strong>Being too vague:</strong> If you say 'write an email', you get a generic email. Use our specific email prompts.</li>
          <li>❌ <strong>Ignoring 'Energy Levels':</strong> Don't try to do a 'High Energy' task when you're in 'Low Energy' mode. The pack categorizes these for a reason!</li>
          <li>❌ <strong>Multitasking with AI:</strong> Keep one chat per specific project to keep the AI's 'memory' clean.</li>
        </ul>
      </div>
    </div>
  );
};
