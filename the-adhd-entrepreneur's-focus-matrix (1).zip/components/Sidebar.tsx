
import React from 'react';

interface SidebarProps {
  currentView: string;
  setView: (view: any) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const menuItems = [
    { id: 'overview', label: 'Product Overview', icon: '📦' },
    { id: 'gumroad', label: 'Gumroad Listing', icon: '💰' },
    { id: 'prompts', label: 'The Prompt Pack', icon: '⚡' },
    { id: 'guide', label: 'Quick-Start Guide', icon: '📖' },
    { id: 'bonus', label: 'Bonus Content', icon: '🎁' },
    { id: 'marketing', label: 'Marketing Assets', icon: '📣' },
    { id: 'launch', label: 'Launch Plan', icon: '🚀' },
  ];

  return (
    <aside className="hidden lg:flex w-72 flex-col bg-white border-r border-slate-200 sticky top-0 h-screen">
      <div className="p-6 border-b border-slate-100">
        <div className="text-xl font-bold text-indigo-600 flex items-center gap-2">
          <span>🌴</span>
          <span>FocusMatrix</span>
        </div>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
              currentView === item.id
                ? 'bg-indigo-50 text-indigo-700'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className="text-lg">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <div className="p-6 border-t border-slate-100 text-xs text-slate-400">
        Ready to Sell from St. Lucia 🇱🇨
      </div>
    </aside>
  );
};
