
import { PromptCategory, FAQItem, MarketingAsset } from './types';

export const PROMPT_PACK_DATA: PromptCategory[] = [
  {
    name: "Category 1: The Morning Executive Function (Plan & Prioritize)",
    description: "Prompts to clear the mental fog and set a realistic path for the day.",
    prompts: [
      {
        id: "p1",
        title: "The Chaotic Brain-Dump Organizer",
        text: "I am going to provide a chaotic, unformatted list of everything currently on my mind—business tasks, personal errands, and random ideas. Your job is to act as an ADHD Productivity Coach. 1. Sort these into 'Crucial for Revenue', 'Important but not Urgent', and 'Distractions/Shiny Objects'. 2. For each 'Crucial' task, provide a one-sentence 'First Step' that takes less than 2 minutes. 3. Rewrite the entire list as a 'Dopamine-Friendly' checklist where tasks are phrased as 'wins' (e.g., 'Finish Email' becomes 'Victory: Sent the Outreach Email'). Output this as a structured table.",
        inputExample: "A list of 15 messy items like 'do laundry, finish client logo, research crypto, email Sarah, fix website footer'.",
        outputExample: "A categorized table with the 3 most important business tasks, clearly defined micro-steps, and a dopamine-boosting checklist.",
        useCase: "Use this first thing in the morning when you feel overwhelmed by a giant to-do list."
      },
      {
        id: "p2",
        title: "The 'Wall of Awful' Break-Through",
        text: "I am currently experiencing task paralysis on a specific project: [Insert Task Name]. I feel [Insert Emotion, e.g., guilt/shame/boredom]. Please act as a supportive project manager. First, validate the difficulty of the task. Second, break this task down into 10 ridiculously small sub-tasks that are impossible to fail. Third, give me a 'Low Energy Version' and a 'High Energy Version' of how to approach this. Finally, tell me what my reward should be after I finish just the first sub-task.",
        inputExample: "Task: Filing quarterly taxes. Emotion: Extreme anxiety.",
        outputExample: "A supportive breakdown starting with 'Log in to the portal' as step 1, plus energy-based options.",
        useCase: "Use when you find yourself staring at a screen for hours unable to start one specific thing."
      },
      {
        id: "p3",
        title: "The Realistic Calendar Auditor",
        text: "Here is my schedule for tomorrow: [Paste Schedule]. Please audit this from an ADHD perspective. Identify where I have failed to account for 'Transition Time' (time to move between tasks) and 'Executive Function Buffers' (recovery time after intense focus). Adjust the schedule to include 15-minute buffers between every major block. If the schedule is over-packed, suggest which two tasks should be moved to the 'Maybe Tomorrow' list based on priority. Output the new 'Human-Friendly' schedule.",
        inputExample: "A back-to-back calendar from 9 AM to 5 PM with no breaks.",
        outputExample: "A spaced-out version of the calendar that actually allows for bathroom breaks and focus recovery.",
        useCase: "Use the night before or morning of to ensure you don't over-commit."
      },
      {
        id: "p4",
        title: "The 'Not-To-Do' Guardrail",
        text: "I am a solo entrepreneur trying to grow my business. My current main goal is [Insert Goal]. Today, I find myself tempted to work on [Insert Distracting Task/Idea]. Please run a 'Friction Analysis'. Tell me why this new task is likely a 'Shiny Object' distraction designed to help me avoid the hard work of my main goal. Provide a 'Park It' note for this idea so I can save it for later without doing it now. Remind me of the top 3 consequences of ignoring my main goal today.",
        inputExample: "Goal: Finishing a course. Distraction: Redesigning my logo for the 5th time.",
        outputExample: "A logical argument against the distraction and a 'save for later' placeholder.",
        useCase: "Use when you feel a 'new exciting idea' trying to hijack your productive hours."
      },
      {
        id: "p5",
        title: "The Sensory-Specific Focus Environment",
        text: "I need to do [Insert Task Type, e.g., deep writing/admin/calls]. Based on ADHD productivity science, suggest a complete 'Sensory Setup' for me. Include: 1. A type of background noise (e.g., Brown Noise, 8-bit lofi). 2. A specific lighting suggestion. 3. A physical 'fidget' or 'grounding' activity to use during breaks. 4. A 'Body Double' suggestion (e.g., using a specific app or website). 5. A time-boxing strategy (e.g., 25/5 Pomodoro vs 90/20 Flow).",
        inputExample: "Task: Writing a 2000-word blog post.",
        outputExample: "A full environment checklist tailored for high-focus writing.",
        useCase: "Use when you can't seem to get 'in the zone'."
      },
      {
        id: "p6",
        title: "The Decision Fatigue Eliminator",
        text: "I am stuck between two choices for my business: [Option A] and [Option B]. I am experiencing decision fatigue. Please analyze both options using a 'Minimum Viable Effort' framework. Which option provides the fastest path to [Desired Result] with the fewest number of steps? Provide a simple Pros/Cons list for each, but emphasize the 'ADHD Interest Factor' (which one is more likely to keep me engaged vs bored). Make a firm recommendation so I can stop thinking and start doing.",
        inputExample: "A: Start a YouTube channel. B: Launch a paid newsletter.",
        outputExample: "A clear recommendation based on energy ROI and engagement potential.",
        useCase: "Use when you are spinning your wheels on a choice and can't move forward."
      }
    ]
  },
  {
    name: "Category 2: The Content Hyperfocus (Marketing & Writing)",
    description: "Systems to capture creative bursts and turn them into finished assets.",
    prompts: [
      {
        id: "p7",
        title: "The 30-Day Content Matrix",
        text: "Act as a Viral Content Strategist. My business is [Describe Business] and my target audience is [Describe Audience]. I need a 30-day content calendar for Instagram and LinkedIn. However, I have ADHD, so I need this organized by 'Energy Levels'. Group the 30 ideas into: 10 'Low Energy' (reposts/memes/short tips), 10 'Medium Energy' (carousel/how-to), and 10 'High Energy' (long-form story/video script). For each idea, provide a one-sentence hook and the primary goal of the post. Output this as a structured monthly grid.",
        inputExample: "Business: Eco-friendly candles. Audience: Busy moms.",
        outputExample: "A 30-day grid with posts labeled by energy requirement.",
        useCase: "Use once a month to remove 'what do I post?' friction."
      },
      {
        id: "p8",
        title: "The 'Speech-to-Polish' Transformer",
        text: "I'm going to paste a rough transcript of my thoughts on [Topic]. Please transform this into: 1. A 500-word SEO blog post. 2. A 3-part thread for X. 3. An engaging LinkedIn post. Keep my voice [Tone] but remove the rambling. Ensure the blog post has headers to make it scannable for readers who also have ADHD.",
        inputExample: "Messy transcript about sustainability.",
        outputExample: "Three polished social/blog assets.",
        useCase: "Use when you can talk about your business but struggle to write it."
      },
      {
        id: "p9",
        title: "The Hook Generator (Anti-Boredom)",
        text: "I have a piece of content about [Topic]. I need 10 different 'Attention-Grabbing Hooks' for the first line. Give me: 2 that use 'Negative Stakes' (fear of missing out), 2 that use 'A Surprising Stat', 2 that use 'Controversial Opinions', 2 that use 'Story-Driven Curiosity', and 2 that are 'Direct and Benefit-Focused'. Each hook must be under 15 words.",
        inputExample: "Topic: Why you should wake up at 5 AM.",
        outputExample: "10 high-conversion hooks.",
        useCase: "Use when you have a good post but the intro feels boring."
      },
      {
        id: "p10",
        title: "The Carousel Scripter",
        text: "Create a 7-slide educational carousel script for Instagram on [Topic]. Structure: Slide 1: Big Hook. Slide 2: The Problem. Slide 3: The Secret/Insight. Slide 4-6: Three actionable steps. Slide 7: Call to Action. For each slide, give me the 'Main Headline' and the 'Visual Description' (what the image should be). Keep the text ultra-minimal—less than 30 words per slide.",
        inputExample: "Topic: 3 ways to fix a leaky faucet.",
        outputExample: "A slide-by-slide script ready for Canva.",
        useCase: "Use to create high-value educational content quickly."
      },
      {
        id: "p11",
        title: "The 'Viral Story' Framework",
        text: "I have a personal story about [Short Description of Event]. Rewrite this into a compelling LinkedIn post that follows the 'Vulnerability-to-Victory' framework. Start with a line that stops the scroll. Show the messy middle where I struggled. End with a clear lesson for other entrepreneurs. Make it emotional but professional. Avoid 'hustle culture' cliches.",
        inputExample: "Failing my first business launch.",
        outputExample: "A high-engagement personal brand post.",
        useCase: "Use when you want to build trust and authority through storytelling."
      },
      {
        id: "p12",
        title: "The Content Repurposing Engine",
        text: "I have this long-form YouTube script/Blog post: [Paste Content]. Please extract 15 'Short-Form Video' (TikTok/Reels) scripts from this content. Each script should be 15-30 seconds long, focus on ONE single insight, and include a 'Hook', 'Value', and 'CTA'. Label each one with the 'Viral Potential' (1-10).",
        inputExample: "A 2,000 word blog post about SEO.",
        outputExample: "15 short, punchy video scripts.",
        useCase: "Use to turn one big piece of work into weeks of social media content."
      }
    ]
  },
  {
    name: "Category 3: The Communication Buffer (Inbox & DMs)",
    description: "Remove the emotional labor of responding to clients and peers.",
    prompts: [
      {
        id: "p13",
        title: "The Polite 'No' Generator",
        text: "I need to decline [Request, e.g., a coffee chat/discount/unpaid speaking gig]. Please write 3 versions of a polite but firm 'No'. Version 1: The 'Not Right Now' (leaving the door open). Version 2: The 'Referral' (suggesting someone else). Version 3: The 'Hard Boundary' (no explanation needed). Keep them under 3 sentences. Do not sound guilty.",
        inputExample: "Request for a free consulting session.",
        outputExample: "3 guilt-free templates for saying no.",
        useCase: "Use when you feel 'people-pleasing' guilt creeping in."
      },
      {
        id: "p14",
        title: "The 'Late Reply' Re-Engager",
        text: "I haven't replied to this email from [Person] in [Time Period]. I feel guilty and overwhelmed by it. Please write a response that acknowledges the delay briefly (without over-explaining or sounding like a failure) and then addresses their original point: [Original Point]. Keep it professional and focused on the future, not the past.",
        inputExample: "Email from a client I ignored for 2 weeks.",
        outputExample: "A smooth, non-apologetic response that gets things back on track.",
        useCase: "Use to kill the 'shame spiral' of unread emails."
      },
      {
        id: "p15",
        title: "The Difficult Client Boundary",
        text: "My client is [Describe Behavior, e.g., messaging me on weekends/asking for extra work]. Write a firm but professional email resetting our boundaries. Remind them of our agreed-upon communication hours and the scope of our contract. Frame this as a way to 'ensure the highest quality of work' for them. Be kind but immovable.",
        inputExample: "Client texting at 11 PM on a Saturday.",
        outputExample: "A professional boundary-setting email.",
        useCase: "Use to protect your personal time without losing a client."
      },
      {
        id: "p16",
        title: "The Cold Outreach 'Anti-Spam'",
        text: "I want to reach out to [Target Person] about [Purpose]. Most cold emails are annoying. Write me an outreach email that is: 1. Short (under 50 words). 2. Highly personalized to their work in [Specific Field]. 3. Asks a 'Low-Friction' question instead of asking for a meeting. Make it sound like a human, not a bot.",
        inputExample: "Target: A local business owner. Purpose: Offering web design.",
        outputExample: "A low-pressure, high-response outreach message.",
        useCase: "Use to grow your network without feeling like a salesperson."
      },
      {
        id: "p17",
        title: "The Testimonial Solicitor",
        text: "I just finished a project with [Client Name]. They were happy. Write a short email asking for a testimonial. Instead of a generic 'can you give me a quote?', provide them with 3 specific prompts they can answer (e.g., 'What was your biggest hesitation?', 'What was the result?'). Make it incredibly easy for them to just reply with a few sentences.",
        inputExample: "Happy client named Dave who I built a site for.",
        outputExample: "An easy-to-answer feedback request.",
        useCase: "Use at the end of every project to build social proof."
      },
      {
        id: "p18",
        title: "The Invoice Follow-up (No Awkwardness)",
        text: "I have an overdue invoice for [Client]. I hate asking for money. Write a sequence of 2 emails. Email 1: A 'Friendly Check-in' (assuming they just forgot). Email 2: A 'Formal Notice' (stating that work will pause if not paid). Remove all 'I'm sorry to bother you' language.",
        inputExample: "Invoice for $500 that is 10 days late.",
        outputExample: "A 2-step sequence that is professional and direct.",
        useCase: "Use when you are avoiding a follow-up because it feels awkward."
      }
    ]
  },
  {
    name: "Category 4: The CEO Strategy Session",
    description: "High-level planning and decision making for your business.",
    prompts: [
      {
        id: "p19",
        title: "The 80/20 Profit Audit",
        text: "Act as a Business Strategist. I will list my current revenue streams and the amount of time/stress each one costs me: [Insert List]. Help me perform an 80/20 audit. Identify the 20% of activities that lead to 80% of my revenue. Identify the 'Drainers'—tasks that take high energy but return low profit. Suggest a plan to 'Double Down' on the winners and 'Phase Out' the losers over the next 90 days.",
        inputExample: "Consulting (high pay, high stress), Courses (low pay, low stress), etc.",
        outputExample: "A strategic roadmap to maximize profit with less effort.",
        useCase: "Use every 3 months to ensure you aren't just 'busy' but actually profitable."
      },
      {
        id: "p20",
        title: "The Quarterly Goal 'Reverse-Engineer'",
        text: "My big goal for the next 90 days is [Insert Goal]. This feels overwhelming. Reverse-engineer this into: 3 Monthly Milestones, 12 Weekly Objectives, and a 'Daily Minimum Requirement' (the one thing I must do every day to stay on track). Ensure the daily task is small enough to do even on a 'Low Energy' day.",
        inputExample: "Goal: Launch my first paid membership with 50 members.",
        outputExample: "A granular, non-overwhelming breakdown of a big goal.",
        useCase: "Use at the start of every quarter."
      },
      {
        id: "p21",
        title: "The 'Post-Mortem' Review",
        text: "I just finished [Project/Launch] and it [Succeeded/Failed/Was Okay]. Help me do a neutral review. 1. What were the 3 biggest wins? 2. Where did I experience the most friction/stress? 3. Was that friction caused by my ADHD (executive function) or by the project itself? 4. What is the 'One Big Lesson' to apply to the next project? Keep it objective and kind.",
        inputExample: "My recent webinar launch where only 5 people showed up.",
        outputExample: "A structured reflection that prevents shame and encourages growth.",
        useCase: "Use after every major business event."
      },
      {
        id: "p22",
        title: "The 'Dream VA' Job Description",
        text: "I am ready to hire my first Virtual Assistant. Based on my current struggles with [Task A, Task B, Task C], write a detailed job description. Include: A list of responsibilities, the 'Personality Type' needed (e.g., high attention to detail to balance my big-picture thinking), and a 15-minute 'Trial Task' to give them during the interview process.",
        inputExample: "I struggle with scheduling, email, and social media posting.",
        outputExample: "A professional job posting tailored to your gaps.",
        useCase: "Use when you are finally ready to delegate."
      },
      {
        id: "p23",
        title: "The Product Pricing Psychology",
        text: "I am launching [Product Name] which is [Description]. My target audience is [Audience]. Help me price this. Give me three options: 1. The 'No-Brainer' price (high volume). 2. The 'Standard' price. 3. The 'Premium/White Glove' price. For each, explain the psychological reasoning and what should be included in the 'Offer Stack' to justify that price.",
        inputExample: "A 1-on-1 coaching package for new photographers.",
        outputExample: "A tiered pricing strategy with logical justifications.",
        useCase: "Use when you are doubting what you should charge."
      },
      {
        id: "p24",
        title: "The Brand 'Vibe' Audit",
        text: "Here is a description of my current website/social media presence: [Description]. My target audience is [Audience]. Please act as a Brand Consultant. Is my current 'vibe' attracting or repelling my target audience? Identify 3 'Cognitive Disconnects' (places where my branding doesn't match my message). Suggest 5 quick fixes to make my brand feel more [Desired Emotion, e.g., trustworthy/bold/luxurious].",
        inputExample: "I sell high-end luxury retreats but my website uses comic sans.",
        outputExample: "A brutally honest brand audit with actionable fixes.",
        useCase: "Use when your traffic is high but your conversions are low."
      }
    ]
  },
  {
    name: "Category 5: The Procrastination Emergency Resets",
    description: "Break glass in case of emergency. Use when the brain says 'no'.",
    prompts: [
      {
        id: "p25",
        title: "The '10-Minute Momentum' Reset",
        text: "I am currently stuck in 'Waiting Mode' and can't start my day. I have been scrolling for [Time]. Please give me a 10-minute 'Reset Protocol'. 1. Give me one 60-second physical task (e.g., wash one dish). 2. Give me one 2-minute business task that feels 'easy'. 3. Remind me that I don't need to be perfect to be productive. Tell me exactly what to do for the next 600 seconds. Ready, go.",
        inputExample: "Been scrolling TikTok for 2 hours and feel like garbage.",
        outputExample: "An immediate, high-energy sequence to break the cycle.",
        useCase: "Use when you feel paralyzed and the guilt is building up."
      },
      {
        id: "p26",
        title: "The 'Overwhelm' Triage",
        text: "I have 20 things to do and I want to quit. Act as a triage nurse for my business. I will list the tasks. You will pick ONLY ONE that I am allowed to work on right now. Tell me to ignore the other 19. Explain why this one is the 'lead domino' that makes everything else easier or unnecessary. Tell me I have permission to do a 'C-' job on it just to get it done.",
        inputExample: "A massive, terrifying to-do list.",
        outputExample: "Focus on one task, permission to be imperfect.",
        useCase: "Use when you are so overwhelmed you are about to shut down."
      },
      {
        id: "p27",
        title: "The Burnout 'Minimum Viable Day'",
        text: "I am on the verge of burnout. My energy is at a 2/10. Write me a 'Minimum Viable Day' schedule. What are the absolute bare-minimum things I must do to keep my business alive today? Everything else must be labeled as 'Not Today'. Give me permission to rest and explain why resting is actually a productive business move for someone with an ADHD brain.",
        inputExample: "I haven't slept and every email feels like a personal attack.",
        outputExample: "A tiny schedule with lots of rest and self-compassion.",
        useCase: "Use when you've pushed too hard and are hitting a wall."
      },
      {
        id: "p28",
        title: "The 'Self-Critic' Silencer",
        text: "I am currently beating myself up because [Reason, e.g., I missed a deadline/forgot an appointment]. My 'Inner Critic' is saying [What it's saying]. Please provide a logical, science-based refutation of these thoughts based on ADHD neurobiology. Explain why this happened (Executive Function fail, not character fail) and give me a 3-step 'Forgiveness and Forward' plan.",
        inputExample: "Forgot a meeting with a VIP client.",
        outputExample: "A kind, logical explanation and a recovery plan.",
        useCase: "Use to stop a shame-spiral before it ruins your week."
      },
      {
        id: "p29",
        title: "The 'Boredom' Pivot",
        text: "I am halfway through a project and I am suddenly bored to tears by it. I want to quit and start something new. Please remind me of my 'Initial Why' for this project. Then, suggest 3 ways I can 'Gamify' the remaining work to make it interesting again (e.g., a challenge, a new tool, a change of scenery). Help me reach the finish line without losing my mind.",
        inputExample: "Writing the last chapter of my eBook.",
        outputExample: "Motivation boosters and gamification strategies.",
        useCase: "Use when the 'shiny new object' syndrome kicks in mid-project."
      },
      {
        id: "p30",
        title: "The Emergency 'Clarity' Call",
        text: "I feel like a fraud today. I feel like my business is a house of cards. Please review my 'Success Evidence': [List 3 past wins]. Remind me that I am capable and that these feelings are a common part of the 'Entrepreneurial Rollercoaster'. Give me one 'Confidence-Boosting' micro-task to do right now to prove to myself that I still have 'it'.",
        inputExample: "Just had a refund request and now I feel like a failure.",
        outputExample: "Perspective shift and a small win task.",
        useCase: "Use when Imposter Syndrome is at an all-time high."
      }
    ]
  }
];

export const FAQ_DATA: FAQItem[] = [
  { question: "How do I use these prompts?", answer: "Simply copy the prompt text, fill in any bracketed information (like [Your Goal]), and paste it into ChatGPT (v4), Claude 3.5, or Gemini." },
  { question: "Do these work with the free version of AI?", answer: "Yes, but for the best results, we recommend using 'Pro' versions (GPT-4 or Claude 3.5 Sonnet) as they handle complex ADHD logic much better." },
  { question: "Can I customize the 'voice'?", answer: "Absolutely! Every prompt includes a section where you can describe your tone. Feel free to change 'professional' to 'snarky' or 'enthusiastic'." },
  { question: "What if the AI gives a boring answer?", answer: "Try adding 'Make it 20% more creative' or 'Explain this to me like I'm a bored teenager' to the end of the chat." },
  { question: "Are these prompts updated for 2025?", answer: "Yes, these are specifically engineered using the latest 2025 AI reasoning capabilities." }
];

export const MARKETING_DATA: MarketingAsset[] = [
  {
    platform: "Twitter/X Thread",
    content: `1/5 🧠 ADHD entrepreneurs: You aren't lazy. You just have a high-performance engine with a tricky starter motor.

I spent 6 months engineering the "Focus Matrix"—30+ AI prompts that act as your external frontal lobe. 

Here is how it changes the game... 🧵

2/5 Most AI prompts are too generic. "Write a blog post" doesn't work for us.

We need prompts that account for:
- Executive dysfunction
- Task paralysis
- The "Wall of Awful"
- Shiny Object Syndrome

3/5 The Focus Matrix includes:
✅ The Chaotic Brain-Dump Organizer
✅ The 'Wall of Awful' Breaker
✅ The 30-Day Energy-Based Content Calendar
✅ The Procrastination Emergency Reset

4/5 Imagine ending your day with a "Checked" list instead of just "Pending" tabs. 

No more guilt. No more "waiting mode." Just pure, automated momentum.

5/5 Grab "The ADHD Entrepreneur's Focus Matrix" today.

Launch Special: $27 (Next 48 Hours only).

Get it here: [YOUR GUMROAD LINK]`
  }
];
