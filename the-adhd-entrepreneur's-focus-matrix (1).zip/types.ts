
export interface Prompt {
  id: string;
  title: string;
  text: string;
  inputExample: string;
  outputExample: string;
  useCase: string;
}

export interface PromptCategory {
  name: string;
  description: string;
  prompts: Prompt[];
}

export interface MarketingAsset {
  platform: string;
  content: string;
  title?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}
